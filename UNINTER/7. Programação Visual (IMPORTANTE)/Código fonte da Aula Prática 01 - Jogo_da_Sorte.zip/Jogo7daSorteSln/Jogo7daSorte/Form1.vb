﻿Public Class Form1
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Num3.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ImagemResultado.Visible = False
        Num1.Text = CStr(Int(Rnd() * 10)) ' Escolhe 1º númro aleatório de 1 a 10
        Num2.Text = CStr(Int(Rnd() * 10)) ' Escolhe 2º númro aleatório de 1 a 10
        Num3.Text = CStr(Int(Rnd() * 10)) ' Escolhe 3º númro aleatório de 1 a 10
        ' Teste da condição de acerto do número 7 nas 3 posições
        'Num1.Text = "7"
        'Num2.Text = "7"
        'Num3.Text = "7"
        ' Se todos os números forem iguais a 7
        If (Num1.Text = "7") And (Num2.Text = "7") And (Num3.Text = "7") Then
            ImagemResultado.Image = Image.FromFile("D:\Desenvolvimento\WinForms\Jogo7daSorteSln\GanhouMax.jpg")
            ImagemResultado.Visible = True
            Beep()
            ' Se um dos números for igual a 7
        ElseIf (Num1.Text = "7") Or (Num2.Text = "7") Or (Num3.Text = "7") Then
            ImagemResultado.Image = Image.FromFile("D:\Desenvolvimento\WinForms\Jogo7daSorteSln\Ganhou.jpg")
            ImagemResultado.Visible = True
            Beep()
            ' Se nenhum dos números for igual a 7
        Else
            ImagemResultado.Image = Image.FromFile("D:\Desenvolvimento\WinForms\Jogo7daSorteSln\Perdeu.jpg")
            ImagemResultado.Visible = True
        End If
    End Sub
End Class
