<!DOCTYPE html>
<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>

<div class="page-header" style="text-align: center;">
<h1>e-Aula 3</h1>
</div>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Inicio</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Link <span class="sr-only">(current)</span></a></li>
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">One more separated link</a></li>
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<form action="index.php" method="post">
<table class="table table-bordered">

<tr>
<td colspan="4"> <input type="text" class="form-control" name="display"></td>
</tr>
<tr>
<td><input type="button" class="btn btn-primary" value="7" onclick="display.value+='7'"></td>
<td><input type="button" class="btn btn-primary" value="8" onClick="display.value+='8'"></td>
<td><input type="button" class="btn btn-primary" value="9" onClick="display.value+='9'"></td>
<td><input type="button" class="btn btn-primary" value="+" onClick="display.value+='+'"></td>
</tr>
<tr>
<td><input type="button" class="btn btn-primary" value="4" onClick="display.value+='4'"></td>
<td><input type="button" class="btn btn-primary" value="5" onClick="display.value+='5'"></td>
<td><input type="button" class="btn btn-primary" value="6" onClick="display.value+='6'"></td>
<td><input type="button" class="btn btn-primary" value="-" onClick="display.value+='-'"></td>
</tr>
<tr>
<td><input type="button" class="btn btn-primary" value="1" onClick="display.value+='1'"></td>
<td><input type="button" class="btn btn-primary" value="2" onClick="display.value+='2'"></td>
<td><input type="button" class="btn btn-primary" value="3" onClick="display.value+='3'"></td>
<td><input type="button" class="btn btn-primary" value="x" onClick="display.value+='*'"></td>
</tr>
<tr>
<td><input type="button" class="btn btn-primary" value="C" onClick="display.value+=''"></td>
<td><input type="button" class="btn btn-primary" value="0" onClick="display.value+='0'"></td>
<td><input type="button" class="btn btn-primary" value="=" onClick="display.value=eval(display.value)"></td>
<td><input type="button" class="btn btn-primary" value="/" onClick="display.value+='/'"></td>
</tr>
</table>
<br/>
<div align="center"><input type="submit" class="btn btn-success" name="btnSalvar" value="Salvar"></div>
</form>    
<?php
if(isset($_POST['btnSalvar'])) 
{
$link = mysqli_connect("localhost","root","");
if(!$link){
    echo ('unable to connect to database');
}
mysqli_select_db($link, "eauladb");
$query = "INSERT INTO calculadora (valor) VALUES ('$_POST[display]')";
$result = mysqli_query($link, $query);

mysqli_close($link);
}


?>
</body>
</html>
