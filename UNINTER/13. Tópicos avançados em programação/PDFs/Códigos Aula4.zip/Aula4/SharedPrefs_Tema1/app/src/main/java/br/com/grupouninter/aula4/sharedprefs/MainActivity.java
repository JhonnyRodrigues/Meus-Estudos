package br.com.grupouninter.aula4.sharedprefs;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnAzul;
    Button btnVermelho;
    Button btnVerde;
    Button btnAmarelo;
    Button btnCeleste;
    Button btnLaranja;
    Button btnGravar;
    RelativeLayout layout;
    EditText edtNome;
    String cor = "#FFFFFF";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAzul = (Button) findViewById(R.id.btnAzul);
        btnVermelho = (Button) findViewById(R.id.btnVermelho);
        btnVerde = (Button) findViewById(R.id.btnVerde);
        btnAmarelo = (Button) findViewById(R.id.btnAmarelo);
        btnCeleste = (Button) findViewById(R.id.btnCeleste);
        btnLaranja = (Button) findViewById(R.id.btnLaranja);
        btnGravar = (Button) findViewById(R.id.btnGravar);
        layout = (RelativeLayout) findViewById(R.id.layoutPrincipal);
        edtNome = (EditText) findViewById(R.id.edtNome);

        btnAzul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#FF15279A";
                layout.setBackgroundColor(Color.parseColor(cor));
            }
        });

        btnVermelho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#ff0011";
                layout.setBackgroundColor(Color.parseColor(cor));
            }
        });

        btnVerde.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#37ff00";
                layout.setBackgroundColor(Color.parseColor(cor));
            }
        });

        btnAmarelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#ffe100";
                layout.setBackgroundColor(Color.parseColor(cor));
            }
        });

        btnCeleste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#00fff7";
                layout.setBackgroundColor(Color.parseColor(cor));
            }
        });

        btnLaranja.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#ff8000";
                layout.setBackgroundColor(Color.parseColor(cor));
            }
        });

        btnGravar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences prefs = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor =  prefs.edit();
                editor.putString("nome", edtNome.getText().toString());
                editor.putString("cor", cor);
                editor.apply();
            }
        });

        carregarPrefs();
    }

    public void carregarPrefs(){
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        edtNome = (EditText) findViewById(R.id.edtNome);
        edtNome.setText(prefs.getString("nome",""));
        cor = prefs.getString("cor", "#FFFFFF");
        layout = (RelativeLayout) findViewById(R.id.layoutPrincipal);
        layout.setBackgroundColor(Color.parseColor(cor));
    }
}

