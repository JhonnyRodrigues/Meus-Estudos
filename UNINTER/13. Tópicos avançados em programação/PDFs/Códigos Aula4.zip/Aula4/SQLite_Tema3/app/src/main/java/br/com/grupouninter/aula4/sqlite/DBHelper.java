package br.com.grupouninter.aula4.sqlite;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Marcelo on 07/08/2016.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String NOME_BANCO_DADOS = "CadastroAmigos";
    private static final int VERSAO_BANCO_DADOS = 1;

    public DBHelper(Context context) {
        super(context, NOME_BANCO_DADOS, null, VERSAO_BANCO_DADOS);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // comando sql responsável pela criação da estrutura da tabela amigos
        String tabela_amigos =  "CREATE TABLE amigos ("
                + "id INTEGER PRIMARY KEY autoincrement,"
                + "nome TEXT,"
                + "telefone TEXT,"
                + "email TEXT"
                + ")";
        // executando o sql de tabela_amigos
        sqLiteDatabase.execSQL(tabela_amigos);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void inserir(Amigo amigo){
        // abrimos a conexão com o arquivo que armazena o banco de dados
        SQLiteDatabase db = this.getWritableDatabase();
        // criamos um statement que recebera a SQL e seus valores a serem passados ao banco
        SQLiteStatement stmt = db.compileStatement("INSERT INTO amigos (nome, telefone, email) " +
                "VALUES (?,?,?)");
        // passamos o valor de nome de amigo ao primeiro argumento de nossa statement (?)
        stmt.bindString(1, amigo.getNome());
        // passamos o valor de telefone ao segundo argumento de nossa statement (?)
        stmt.bindString(2, amigo.getTelefone());
        // passamos o valor de email ao terceiro argumento de nossa statement (?)
        stmt.bindString(3, amigo.getEmail());
        // executamos o statement
        stmt.execute();
        // fechamos o objeto Statement
        stmt.close();
        // fechamos o arquivo de banco de dados
        db.close();
    }

    public void atualizar(Amigo amigo){
        // abrimos a conexão com o arquivo que armazena o banco de dados
        SQLiteDatabase db = this.getWritableDatabase();
        // criamos um statement que recebera a SQL e seus valores a serem passados ao banco
        SQLiteStatement stmt = db.compileStatement("UPDATE amigos SET nome=?, telefone=?, email=? "+
                "WHERE id = ?");
        // passamos o valor de nome de amigo ao primeiro argumento de nossa statement (?)
        stmt.bindString(1, amigo.getNome());
        // passamos o valor de telefone ao segundo argumento de nossa statement (?)
        stmt.bindString(2, amigo.getTelefone());
        // passamos o valor de email ao terceiro argumento de nossa statement (?)
        stmt.bindString(3, amigo.getEmail());
        // passamos o valor de id ao quarto argumento de nossa statement (?)
        stmt.bindLong(4, amigo.getId());
        // executamos o statement
        stmt.execute();
        // fechamos o objeto Statement
        stmt.close();
        // fechamos o arquivo de banco de dados
        db.close();
    }

    public void excluir(int id){
        // abrimos a conexão com o arquivo que armazena o banco de dados
        SQLiteDatabase db = this.getWritableDatabase();
        // criamos um statement que recebera a SQL e seus valores a serem passados ao banco
        SQLiteStatement stmt = db.compileStatement("DELETE FROM amigos WHERE id = ?");
        // passamos o valor de id de amigo ao primeiro argumento de nossa statement (?)
        stmt.bindLong(1, id);
        // executamos o statement
        stmt.execute();
        // fechamos o objeto Statement
        stmt.close();
        // fechamos o arquivo de banco de dados
        db.close();
    }

    public Amigo retornarAmigo(int id){
        // abrimos a conexão com o arquivo que armazena o banco de dados
        SQLiteDatabase db = this.getWritableDatabase();
        // comando sql que retornará o id, nome, telefone e email de um amigo com base no id passado
        String query = "SELECT id, nome, telefone, email FROM amigos WHERE id = ?";
        // definimos um cursor - objeto que receberá os registros que atendam os requisitos da query criada
        Cursor cursor = db.rawQuery(query, new String[] {String.valueOf(id)});
        // movemos o cursor para o primeiro registro encontrado
        cursor.moveToFirst();
        // instanciamos o objeto amigo
        Amigo amigo = new Amigo();
        // definimos suas propriedades com base nas colunas existentes no cursor
        amigo.setId(cursor.getInt(0));
        amigo.setNome(cursor.getString(1));
        amigo.setTelefone(cursor.getString(2));
        amigo.setEmail(cursor.getString(3));
        // fechamos o arquivo do banco de dados
        db.close();
        // retornamos o pojo devidamente preenchido
        return amigo;
    }

    public ArrayList<Amigo> listar(){
        // criamos uma List que armazenará objetos do tipo Amigo
        ArrayList amigos = new ArrayList<Amigo>();
        // abrimos a conexão com o arquivo que armazena o banco de dados
        SQLiteDatabase db = this.getWritableDatabase();
        // Buscamos todos os registros disponiveis no banco de dados ordenados por nome
        String query = "Select id, nome, telefone, email FROM amigos ORDER BY nome";
        Cursor cursor = db.rawQuery(query, null);
        // iteramos por todos os registros localizados com base em nossa query
        while (cursor.moveToNext()) {
            // instanciamos um novo objeto amigo
            Amigo amigo = new Amigo();
            // preenchemos este objeto com os valores armazenados no cursor
            amigo.setId(cursor.getInt(0));
            amigo.setNome(cursor.getString(1));
            amigo.setTelefone(cursor.getString(2));
            amigo.setEmail(cursor.getString(3));
            // adicionamos o objeto preenchido à nossa List de amigos
            amigos.add(amigo);
        }
        // retornamos o objeto Amigos ao método que o chamou
        return amigos;
    }


}
