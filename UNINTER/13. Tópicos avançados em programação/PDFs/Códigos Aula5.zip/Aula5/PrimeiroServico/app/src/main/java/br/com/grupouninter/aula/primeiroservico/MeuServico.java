package br.com.grupouninter.aula.primeiroservico;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * Created by Marcelo on 20/08/2016.
 */
public class MeuServico extends Service {

    private static String TAG = "MeuServico";

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind()");
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand()");
        this.stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy(){
        Log.d(TAG, "onDestroy()");
        super.onDestroy();
    }
}
