package br.com.grupouninter.aula.androidxmlparser;

/**
 * Created by Marcelo on 21/08/2016.
 */
public class RssUOL {

    private String titulo;
    private String link;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
