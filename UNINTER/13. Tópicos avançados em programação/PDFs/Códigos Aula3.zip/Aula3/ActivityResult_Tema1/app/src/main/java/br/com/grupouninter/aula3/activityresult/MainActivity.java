package br.com.grupouninter.aula3.activityresult;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView resultado;
    Button btnOpcao;
    static int ACAO_BUSCA_PREFERENCIA_USER = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // ligamos o componente btnOpcao à representação no arquivo xml
        btnOpcao = (Button) findViewById(R.id.btnOpcao);
        // redefinimos o listener OnClickListener
        btnOpcao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), SegundaActivity.class);
                startActivityForResult(intent, ACAO_BUSCA_PREFERENCIA_USER);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        // verificando o tipo de request code
        if (requestCode == ACAO_BUSCA_PREFERENCIA_USER){
            // verificando se o usuário encerrou a activity retornando sua opcao
            if (resultCode == RESULT_OK){
                // ligamos o componente resultado à representação no arquivo xml
                resultado = (TextView) findViewById(R.id.resultado);
                // passamos o valor da Intent (uma String) para resultado.setText()
                resultado.setText(data.getStringExtra("retorno"));
            }
        }
    }
}
