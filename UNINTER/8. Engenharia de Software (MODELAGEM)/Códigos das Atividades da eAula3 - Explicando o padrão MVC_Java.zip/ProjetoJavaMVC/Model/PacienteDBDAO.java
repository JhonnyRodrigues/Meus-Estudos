package Model;

import java.sql.SQLException;

import java.sql.PreparedStatement;

public class PacienteDBDAO extends Conexao{
	
	public boolean incluir (Paciente paciente) {
		boolean sucesso = false;
		String sql = "INSERT INTO Paciente (codigo, nome, endereco) VALUES (?, ?, ?)";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setInt(1, paciente.getCodigo());
			pst.setString(2, paciente.getNome());
			pst.setString(3, paciente.getEndereco());
			pst.execute();
			sucesso = true;
			pst.close();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir o paciente");
			e.printStackTrace();
		}
		return sucesso;
	}

}
