package Model;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class Conexao {
	Connection connection = null;
		static {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				System.out.println("Erro ao instanciar classe de conex�o");
				e.printStackTrace();
			}
		}
		
		public Connection getConnection() {
			try {
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Clinica", "root", "root");
				System.out.println("Conectado com sucesso.");
			} catch (SQLException e) {
				System.out.println("Erro ao conectar no banco de dados.");
				e.printStackTrace();
			}
			return connection;
		}
		
		public static void main (String[] args) {
			Conexao conexao = new Conexao();
			conexao.getConnection();
		}

}
