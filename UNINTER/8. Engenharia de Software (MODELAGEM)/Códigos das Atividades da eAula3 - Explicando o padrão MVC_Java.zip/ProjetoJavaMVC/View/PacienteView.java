package View;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Control.PacienteControl;
import Model.Paciente;

public class PacienteView extends JFrame implements ActionListener {
	
	private JLabel lblCodigo;
	private JLabel lblNome;
	private JLabel lblEndereco;
	
	private JTextField txtCodigo;
	private JTextField txtNome;
	private JTextField txtEndereco;
	
	private JButton btnIncluir;
	
	PacienteControl control = new PacienteControl();
	
	public PacienteView() {
		super("Cadastro de Pacientes");
		
		setSize(550, 450);
		
		lblCodigo   = new JLabel("Codigo");
		lblNome     = new JLabel("Nome");
		lblEndereco = new JLabel("Endere�o");
		
		txtCodigo = new JTextField("");
		txtNome = new JTextField("");
		txtEndereco = new JTextField("");
		
		btnIncluir = new JButton("Incluir");
		
		getContentPane().setLayout(null);
		getContentPane().add(lblCodigo);
		getContentPane().add(lblNome);
		getContentPane().add(lblEndereco);
		getContentPane().add(txtCodigo);
		getContentPane().add(txtNome);
		getContentPane().add(txtEndereco);
		getContentPane().add(btnIncluir);
		btnIncluir.addActionListener(this);
		
		lblCodigo.setBounds(20, 20, 100, 15);
		txtCodigo.setBounds(20, 40, 80, 25);
		lblNome.setBounds(20, 80, 100, 15);
		txtNome.setBounds(20, 100, 150, 25);
		lblEndereco.setBounds(20, 140, 100, 15);
		txtEndereco.setBounds(20, 160, 180, 25);
		btnIncluir.setBounds(20, 200, 100, 20);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		Object src = e.getSource();
		Paciente paciente = new Paciente();
		boolean sucesso = false;
		try {
			if (src == btnIncluir) {
				sucesso = control.incluir(paciente);
			}
		}catch (Exception e1){
			JOptionPane.showMessageDialog(null, e1.getMessage(), "Falha no processo de incluir um paciente", JOptionPane.ERROR_MESSAGE);
		}
	}
}
