package Control;

import Model.Paciente;
import Model.PacienteDBDAO;

public class PacienteControl {
	
	public boolean incluir (Paciente paciente) {
		boolean sucesso = false;
		PacienteDBDAO dao = new PacienteDBDAO();
		sucesso = dao.incluir(paciente);
		return sucesso;
	}

}
