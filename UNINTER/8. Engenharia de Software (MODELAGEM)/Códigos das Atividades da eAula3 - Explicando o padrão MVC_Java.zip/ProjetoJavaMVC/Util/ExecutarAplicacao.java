package Util;

import View.PacienteView;

public class ExecutarAplicacao {

	public static void main(String[] args) {
		PacienteView pv = new PacienteView();
		pv.setVisible(true);

	}

}
