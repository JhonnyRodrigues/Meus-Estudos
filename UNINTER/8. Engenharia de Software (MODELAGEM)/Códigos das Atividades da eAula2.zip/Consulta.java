import java.sql.Date;

public class Consulta {
	public String data;
	public Medico medico;
	public Paciente paciente;
	public Enfermeiro enfermeiro;
	
	public Consulta(String data, Medico medico, Paciente paciente){
		this.setData(data);
		this.setMedico(medico);
		this.setPaciente(paciente);
	}
	
	public Consulta(String data, Medico medico, Paciente paciente, Enfermeiro enfermeiro){
		this.setData(data);
		this.setMedico(medico);
		this.setPaciente(paciente);
		this.setEnfermeiro(enfermeiro);
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Enfermeiro getEnfermeiro() {
		return enfermeiro;
	}

	public void setEnfermeiro(Enfermeiro enfermeiro) {
		this.enfermeiro = enfermeiro;
	}

	@Override
	public String toString() {
		return "FAZEM PARTE DESTA CONSULTA OS SEGUINTES INTEGRANTES" + "\n" +
				this.getPaciente() + "\n" +
				this.getMedico() + "\n" +
				this.getEnfermeiro();
	}
	
}
