
public class Medico extends Pessoa {
	public int crm;
	
	public Medico(String nome, int idade, float peso, float altura, int crm){
		super(nome, idade, peso, altura);
		this.setCrm(crm);
	}

	public int getCrm() {
		return crm;
	}

	public void setCrm(int crm) {
		this.crm = crm;
	}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				"CRM: " + this.getCrm();
	}

}
