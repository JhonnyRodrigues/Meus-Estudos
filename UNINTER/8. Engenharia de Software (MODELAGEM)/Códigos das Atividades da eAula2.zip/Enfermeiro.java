
public class Enfermeiro extends Pessoa {
	public int coren;
	
	public Enfermeiro(String nome, int idade, float peso, float altura, int coren){
		super(nome, idade, peso, altura);
		this.setCoren(coren);
	}

	public int getCoren() {
		return coren;
	}

	public void setCoren(int coren) {
		this.coren = coren;
	}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				"Coren: " + this.getCoren();
	}
	
}
