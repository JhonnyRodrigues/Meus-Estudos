
public class Paciente extends Pessoa {
	public int cpf;
	
	public Paciente(String nome, int idade, float peso, float altura, int cpf){
		super(nome, idade, peso, altura);
		this.setCpf(cpf);
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				"CPF: " + this.getCpf();
	}
	
}
