import java.sql.Date;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		String nomeM;
		String nomeP;
		String nomeE;
		int idadeM;
		int idadeP;
		int idadeE;
		float pesoM;
		float pesoP;
		float pesoE;
		float alturaM;
		float alturaP;
		float alturaE;
		int crm;
		int cpf;
		int coren;
		String data;
		String ae;
		
		Scanner dados = new Scanner(System.in);
		
		System.out.println("Digite a data da consulta: ");
		data = dados.nextLine();
		System.out.println("Digite o nome do M�dico da Consulta: ");
		nomeM = dados.nextLine();
		System.out.println("Digite a idade do M�dico: ");
		idadeM = dados.nextInt();
		System.out.println("Digite o CRM do M�dico: ");
		crm = dados.nextInt();
		System.out.println("Digite o peso do M�dico: ");
		pesoM = dados.nextFloat();
		System.out.println("Digite a altura do M�dico: ");
		alturaM = dados.nextFloat();
		System.out.println("Digite o nome do Paciente da Consulta: ");
		nomeP = dados.next();
		System.out.println("Digite a idade do Paciente: ");
		idadeP = dados.nextInt();
		System.out.println("Digite o CPF do Paciente: ");
		cpf = dados.nextInt();
		System.out.println("Digite o peso do Paciente: ");
		pesoP = dados.nextFloat();
		System.out.println("Digite a altura do Paciente: ");
		alturaP = dados.nextFloat();
		System.out.println("Deseja adicionar o Enfermeiro na consulta? S ou N");
		ae = dados.next();
		
		if (ae.equals("S")){
			System.out.println("Digite o nome do Enfermeiro: ");
			nomeE = dados.next();
			System.out.println("Digite a idade do Enfermeiro: ");
			idadeE = dados.nextInt();
			System.out.println("Digite o Coren do Enfermeiro: ");
			coren = dados.nextInt();
			System.out.println("Digite o peso do Enfermeiro: ");
			pesoE = dados.nextFloat();
			System.out.println("digite a altura do Enfermeiro: ");
			alturaE = dados.nextFloat();
			Medico medico = new Medico(nomeM, idadeM, pesoM, alturaM, crm);
			Paciente paciente = new Paciente(nomeP, idadeP, pesoP, alturaP, cpf);
			Enfermeiro enfermeiro = new Enfermeiro(nomeE, idadeE, pesoE, alturaE, coren);
			Consulta consulta = new Consulta(data, medico, paciente, enfermeiro);
			System.out.println(consulta);
		} else {
			Medico medico = new Medico(nomeM, idadeM, pesoM, alturaM, crm);
			Paciente paciente = new Paciente(nomeP, idadeP, pesoP, alturaP, cpf);
			Consulta consulta = new Consulta(data, medico, paciente);
			System.out.println(consulta);
		}
	}

}
